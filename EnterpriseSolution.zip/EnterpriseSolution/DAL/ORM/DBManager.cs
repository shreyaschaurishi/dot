﻿using BOL;
using MySql.Data.MySqlClient;

namespace DAL.ORM;

public class MySqlDBManager{
    public MySqlDBManager(){}
    public List<Employee> GetAll(){
        List<Employee> employees=new List<Employee>();
        //*********************
        
        return employees;
    }
    public  Employee GetById(int id){
        Employee  employee=new Employee();
       
        return employee;
    }

}